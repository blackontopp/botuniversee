import discord
from discord.ext import commands
import config  # Assurez-vous d'importer config.py

# Création des intents
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix='+', intents=intents, help_command=None)

@bot.event
async def on_ready():
    print(f'Bot connecté sous {bot.user}')

    # Changer l'activité du bot en mode "Regarde"
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="R-HostBot"))

    # Récupérer le salon spécifique pour envoyer l'embed
    channel = bot.get_channel(1348323989964980367)

    if channel:
        # Créer l'embed pour annoncer que le bot est allumé
        embed = discord.Embed(
            title="**Bot allumé et fonctionnel !**",
            description="Le bot `SupportBot V2` du serveur **NOM_Du_serveur** est maintenant en ligne et prêt à vous aider !",
            color=0x4adedd,
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text="SupportBot V2 | Bot en ligne")
        embed.set_thumbnail(url=bot.user.avatar.url)

        embed.add_field(name="✅ Statut", value="Le bot fonctionne parfaitement.", inline=False)
        embed.add_field(name="💻 Version", value="SupportBot V2", inline=True)
        embed.add_field(name="🎮 Activité", value="Regarde STATUT", inline=True)
        embed.add_field(name="🚀 Lancement", value="Bot allumé avec succès", inline=False)

        # Envoyer l'embed dans le salon
        await channel.send(embed=embed)
    else:
        print("Le salon n'a pas été trouvé.")

    # Charger les cogs au démarrage
    try:
        cogs = [
            'cogs.info.serveurinfo',
            'cogs.info.userinfo',
            'cogs.info.pdp',
            'cogs.autre.cmd',
            'cogs.autre.ping',
            'cogs.autre.mp',
            'cogs.autre.sniped',
            'cogs.nosupp.roles',
            'cogs.nosupp.restart',
            'cogs.nosupp.new_serv',
            'cogs.nosupp.servers',
            'cogs.nosupp.presence',
            'cogs.nosupp.pers',
            'cogs.hide_lock.locker',
            'cogs.hide_lock.massivelock',
            'cogs.hide_lock.hidder',
            'cogs.hide_lock.massivehide',
            'cogs.gest_role.roles',
            'cogs.gest_role.massiverole',
            'cogs.gest_msg.say',
            'cogs.gest_msg.embed',
            'cogs.gest_msg.msg',
            'cogs.moderation.timeout',
            'cogs.moderation.kick',
            'cogs.moderation.banned',
            'cogs.moderation.blacklist',
            'cogs.moderation.warn',
            'cogs.systeme.sugg_config',
            'cogs.systeme.suggest',
            'cogs.systeme.wlcm_config',
            'cogs.error',
            'cogs.help'
        ]
        
        for cog in cogs:
            await bot.load_extension(cog)
        print("Cogs chargés avec succès !")
        
    except Exception as e:
        print(f"Erreur lors du chargement du cog : {e}")

@bot.event
async def on_message(message):
    # Ignorer les messages envoyés par le bot lui-même
    if message.author == bot.user:
        return

    # Traite les commandes manuellement si tu fais un traitement personnalisé
    await bot.process_commands(message)

# Lancer le bot
bot.run(config.TOKEN)