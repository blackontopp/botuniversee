import discord
from discord.ext import commands
from discord import ui
import json

# Charger la configuration du serveur
CONFIG_FILE = "data/suggest_config.json"

def load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"suggest_channel": None, "mod_role": None}

class Suggestion(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="suggestion", aliases=["suggest"])
    async def suggestion(self, ctx, *, message: str):
        config = load_config()
        suggest_channel_id = config.get("suggest_channel")
        mod_role_id = config.get("mod_role")

        if suggest_channel_id is None or mod_role_id is None:
            await ctx.send("La configuration n'a pas été définie.")
            return

        # Vérifier si le salon existe
        suggest_channel = self.bot.get_channel(suggest_channel_id)
        if suggest_channel is None:
            await ctx.send("Le salon de suggestions n'a pas été trouvé.")
            return

        # Créer l'embed
        embed = discord.Embed(
            title="💡 Nouvelle Suggestion",
            description=message,
            color=0x9884fe
        )
        embed.add_field(name="📝 Auteur", value=ctx.author.mention, inline=False)
        embed.set_footer(text=f"Suggéré par {ctx.author.display_name}")

        # Ajouter les boutons
        view = SuggestionButtons(embed, mod_role_id)
        await suggest_channel.send(embed=embed, view=view)

        # Supprimer le message original
        await ctx.message.delete()

class SuggestionButtons(ui.View):
    def __init__(self, embed, mod_role_id):
        super().__init__(timeout=None)
        self.embed = embed
        self.mod_role_id = mod_role_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Vérifie si l'utilisateur a le rôle modérateur."""
        if any(role.id == self.mod_role_id for role in interaction.user.roles):
            return True
        await interaction.response.send_message("❌ Tu n'as pas la permission d'utiliser ce bouton.", ephemeral=True)
        return False

    @ui.button(label="Accepter", style=discord.ButtonStyle.secondary)
    async def accept(self, interaction: discord.Interaction, button: ui.Button):
        """Quand on clique sur Accepter, l'embed devient vert et les boutons disparaissent."""
        self.embed.color = 0x00c076  # Vert
        self.embed.set_footer(text=f"Accepté par {interaction.user.display_name}")
        await interaction.response.edit_message(embed=self.embed, view=None)

    @ui.button(label="Décliner", style=discord.ButtonStyle.secondary)
    async def decline(self, interaction: discord.Interaction, button: ui.Button):
        """Quand on clique sur Décliner, ouvre un formulaire pour entrer une raison."""
        await interaction.response.send_modal(DeclineReasonModal(self.embed))

class DeclineReasonModal(ui.Modal):
    def __init__(self, embed):
        super().__init__(title="Raison du refus")
        self.embed = embed
        self.reason = ui.TextInput(label="Raison", placeholder="Indiquez pourquoi cette suggestion est refusée", max_length=200)
        self.add_item(self.reason)

    async def on_submit(self, interaction: discord.Interaction):
        """Quand le formulaire est validé, met à jour l'embed avec la raison."""
        self.embed.color = 0xff6b6b  # Rouge
        self.embed.add_field(name="❌ Raison du refus", value=self.reason.value, inline=False)
        self.embed.set_footer(text=f"Refusé par {interaction.user.display_name}")
        await interaction.response.edit_message(embed=self.embed, view=None)

async def setup(bot):
    await bot.add_cog(Suggestion(bot))