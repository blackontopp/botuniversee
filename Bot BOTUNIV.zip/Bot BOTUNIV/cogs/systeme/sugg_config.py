import discord
import json
from discord.ext import commands
from asyncio import TimeoutError

CONFIG_FILE = "data/suggest_config.json"
ROLES_FILE = "data/roles.json"

# Fonction pour vérifier si un utilisateur est Owner ou Buyer
def has_role(user_id, role):
    try:
        with open(ROLES_FILE, "r") as f:
            roles_data = json.load(f)
        return str(user_id) in roles_data.get(role, [])
    except FileNotFoundError:
        return False

class SuggestConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="suggest-config")
    async def suggest_config(self, ctx):
        """ Ouvre la configuration des suggestions (Salon / Rôle) """
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(
                description="❌ **Tu n'as pas la permission d'utiliser cette commande.**",
                color=0x9884fe
            )
            return await ctx.send(embed=embed, delete_after=5)

        config = self.load_config()
        embed, view = self.generate_embed()
        await ctx.send(embed=embed, view=view)

    def load_config(self):
        """ Charge la configuration des suggestions """
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {"suggest_channel": None, "mod_role": None}

    def save_config(self, config):
        """ Sauvegarde la configuration """
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)

    def generate_embed(self):
        """ Génère l'embed de configuration avec les valeurs actuelles """
        config = self.load_config()
        suggest_channel = f"<#{config['suggest_channel']}>" if config["suggest_channel"] else "❌ Aucun défini"
        mod_role = f"<@&{config['mod_role']}>" if config["mod_role"] else "❌ Aucun défini"

        embed = discord.Embed(
            title="⚙️ Configuration des Suggestions",
            description="Sélectionne une option pour modifier la configuration.",
            color=0x9884fe
        )
        embed.add_field(name="📢 Salon des Suggestions", value=suggest_channel, inline=False)
        embed.add_field(name="🛡️ Rôle de Modération", value=mod_role, inline=False)

        view = SuggestConfigView(self)
        return embed, view

    async def wait_for_response(self, interaction: discord.Interaction, setting):
        """ Attend un message de l'utilisateur pour mettre à jour la config """
        try:
            await interaction.response.send_message(
                f"📝 Envoie l'ID ou mentionne le **{'salon des suggestions' if setting == 'suggest_channel' else 'rôle de modération'}**.",
                ephemeral=True
            )

            msg = await self.bot.wait_for(
                "message",
                check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel.id,
                timeout=30
            )
            await msg.delete()

            config = self.load_config()

            if setting == "suggest_channel":
                if msg.content.isdigit():
                    config["suggest_channel"] = int(msg.content)
                elif msg.channel_mentions:
                    config["suggest_channel"] = msg.channel_mentions[0].id
                else:
                    return await interaction.channel.send(
                        embed=discord.Embed(
                            description="⚠️ **Salon invalide.** Envoie l'ID ou mentionne le salon.",
                            color=0x9884fe
                        ), delete_after=5
                    )

            elif setting == "mod_role":
                if msg.content.isdigit():
                    config["mod_role"] = int(msg.content)
                elif msg.role_mentions:
                    config["mod_role"] = msg.role_mentions[0].id
                else:
                    return await interaction.channel.send(
                        embed=discord.Embed(
                            description="⚠️ **Rôle invalide.** Envoie l'ID ou mentionne le rôle.",
                            color=0x9884fe
                        ), delete_after=5
                    )

            self.save_config(config)

            # Mettre à jour l'embed en temps réel
            new_embed, new_view = self.generate_embed()
            await interaction.message.edit(embed=new_embed, view=new_view)

        except TimeoutError:
            await interaction.channel.send(
                embed=discord.Embed(
                    description="⏳ **Temps écoulé. Recommence la configuration.**",
                    color=0x9884fe
                ), delete_after=5
            )

class SuggestConfigView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=60)
        self.cog = cog

    @discord.ui.select(
        placeholder="🔽 Choisis une option...",
        options=[
            discord.SelectOption(label="📢 Salon des Suggestions", value="suggest_channel", emoji="📢"),
            discord.SelectOption(label="🛡️ Rôle de Modération", value="mod_role", emoji="🛡️")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        setting = select.values[0]
        await self.cog.wait_for_response(interaction, setting)

async def setup(bot):
    await bot.add_cog(SuggestConfig(bot))