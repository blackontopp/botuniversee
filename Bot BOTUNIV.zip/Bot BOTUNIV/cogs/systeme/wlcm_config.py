import discord
from discord.ext import commands
import json
import os

CONFIG_FILE = "data/welcome_config.json"
ROLES_FILE = "data/roles.json"

def has_role(user_id, role):
    """ Vérifie si un utilisateur possède un rôle spécifique """
    try:
        with open(ROLES_FILE, "r") as f:
            roles_data = json.load(f)
        return str(user_id) in roles_data.get(role, [])
    except FileNotFoundError:
        return False

def load_config():
    """ Charge la configuration depuis le fichier JSON """
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def save_config(config):
    """ Sauvegarde la configuration dans le fichier JSON """
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)

VARIABLES = {
    "{user}": "Mention du membre",
    "{username}": "Nom du membre",
    "{server}": "Nom du serveur",
    "{membercount}": "Nombre total de membres",
    "{id}": "ID du membre",
    "{tag}": "Tag du membre (ex: User#0001)",
    "{created}": "Date de création du compte",
    "{joined}": "Date d’arrivée sur le serveur",
    "{mention}": "Mention du membre",
    "{newline}": "Saut de ligne"
}

class WelcomeConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = load_config()

    async def update_embed(self, guild_id):
        """ Met à jour l'embed de configuration """
        config = self.config.get(str(guild_id), {})

        salon = f"<#{config.get('channel')}>" if config.get("channel") else "Non défini"
        role = f"<@&{config.get('role')}>" if config.get("role") else "Non défini"
        message = config.get("message", "Non défini")

        embed = discord.Embed(
            title="🔧 Configuration du système d’accueil",
            description="Choisissez une option pour configurer votre message d’accueil.",
            color=0x9884fe
        )
        embed.add_field(name="📌 Salon d'arrivée", value=salon, inline=False)
        embed.add_field(name="🎭 Rôle d'arrivée", value=role, inline=False)
        embed.add_field(name="📜 Message d'arrivée", value=f"```{message}```", inline=False)
        embed.set_footer(text="Mettez à jour les paramètres avec le menu ci-dessous.")

        return embed

    @commands.command(aliases=["welcome-settings", "setwelcome"])
    async def welcome_config(self, ctx):
        """ Configure le système d'accueil """
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'utiliser cette commande.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        embed = await self.update_embed(ctx.guild.id)
        view = WelcomeView(self, ctx.guild.id)

        await ctx.send(embed=embed, view=view)

    @commands.command()
    async def variable(self, ctx):
        """ Affiche les variables disponibles pour le message d’arrivée """
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'utiliser cette commande.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        desc = "\n".join([f"{var} → {desc}" for var, desc in VARIABLES.items()])
        embed = discord.Embed(
            title="📌 Variables disponibles",
            description=f"Utilisez ces variables dans votre message d’arrivée :\n\n{desc}",
            color=0x9884fe
        )
        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """ Envoie un message d’arrivée et donne le rôle configuré """
        guild_id = str(member.guild.id)
        config = self.config.get(guild_id, {})

        salon_id = config.get("channel")
        role_id = config.get("role")
        message = config.get("message", "")

        if not salon_id or not message:
            return

        salon = self.bot.get_channel(salon_id)
        role = member.guild.get_role(role_id) if role_id else None

        welcome_message = message.format(
            user=member.mention,
            username=member.name,
            server=member.guild.name,
            membercount=len(member.guild.members),
            id=member.id,
            tag=str(member),
            created=member.created_at.strftime("%d/%m/%Y"),
            joined=member.joined_at.strftime("%d/%m/%Y"),
            mention=member.mention,
            newline="\n"
        )

        if salon:
            await salon.send(welcome_message)
        if role:
            await member.add_roles(role, reason="Rôle d'arrivée automatique")

class WelcomeView(discord.ui.View):
    def __init__(self, cog, guild_id):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id

    @discord.ui.select(
        placeholder="🔧 Choisissez une option...",
        options=[
            discord.SelectOption(label="📌 Salon d'arrivée", value="channel"),
            discord.SelectOption(label="🎭 Rôle d'arrivée", value="role"),
            discord.SelectOption(label="📜 Message d'arrivée", value="message")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        setting = select.values[0]
        await self.wait_for_response(interaction, setting)

    async def wait_for_response(self, interaction, setting):
        """ Attend une réponse pour modifier la configuration """
        await interaction.response.send_message(f"✏️ **Envoie la nouvelle valeur pour {setting} :**", ephemeral=True)

        def check(m):
            return m.author == interaction.user and m.channel == interaction.channel

        try:
            msg = await self.cog.bot.wait_for("message", check=check, timeout=60)
            new_value = msg.content

            if setting in ["channel", "role"]:
                if not msg.content.isdigit():
                    return await interaction.channel.send("❌ **ID invalide.**")
                new_value = int(msg.content)

            if setting == "message" and len(new_value) > 1000:
                return await interaction.channel.send("❌ **Le message est trop long (max 1000 caractères).**")

            guild_id = str(self.guild_id)
            if guild_id not in self.cog.config:
                self.cog.config[guild_id] = {}

            self.cog.config[guild_id][setting] = new_value
            save_config(self.cog.config)

            await msg.delete()
            await interaction.channel.send(f"✅ **{setting.capitalize()} mis à jour avec succès !**", delete_after=5)

            embed = await self.cog.update_embed(self.guild_id)
            await interaction.message.edit(embed=embed)

        except Exception:
            await interaction.channel.send("❌ **Temps écoulé ou erreur.**", delete_after=5)

async def setup(bot):
    await bot.add_cog(WelcomeConfig(bot))