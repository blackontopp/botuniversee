import discord
from discord.ext import commands
import json
import os

CONFIG_FILE = "data/ticket_config.json"

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {
            "select_channel": None,
            "select_message": None,
            "close_on_leave": False,
            "options": {}
        }
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)

def has_role(user_id, role):
    try:
        with open('data/roles.json', 'r') as f:
            roles_data = json.load(f)
        return str(user_id) in roles_data.get(role, [])
    except FileNotFoundError:
        return False

class TicketConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=["ticket-config"])
    async def ticketset(self, ctx):
        """Configure le système de tickets (Buyer et Owner uniquement)."""
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'utiliser cette commande.**", color=0x4193f5)
            await ctx.send(embed=embed)
            return

        config = load_config()

        embed = discord.Embed(title="🎫 Configuration des Tickets", color=0x4193f5)
        embed.add_field(name="Salon du Sélecteur", value=f"<#{config.get('select_channel') or 'Non défini'}>", inline=False)
        embed.add_field(name="Message du Sélecteur", value=f"ID: `{config.get('select_message') or 'Non défini'}`", inline=False)
        embed.add_field(name="Fermeture Auto", value="✅ Activée" if config["close_on_leave"] else "❌ Désactivée", inline=False)

        view = TicketConfigView(ctx, config)
        await ctx.send(embed=embed, view=view)

class TicketConfigView(discord.ui.View):
    def __init__(self, ctx, config):
        super().__init__(timeout=None)
        self.ctx = ctx
        self.config = config

    @discord.ui.select(
        placeholder="🎛 Modifier les paramètres",
        options=[
            discord.SelectOption(label="Modifier le salon du sélecteur", emoji="🏢"),
            discord.SelectOption(label="Modifier le message du sélecteur", emoji="📩"),
            discord.SelectOption(label="Activer/Désactiver fermeture auto", emoji="🔒")
        ]
    )
    async def select_settings(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.defer()
        choice = select.values[0]

        if choice == "Modifier le salon du sélecteur":
            await self.wait_for_response(interaction, "Salon", "select_channel")

        elif choice == "Modifier le message du sélecteur":
            await self.wait_for_response(interaction, "ID du Message", "select_message")

        elif choice == "Activer/Désactiver fermeture auto":
            self.config["close_on_leave"] = not self.config["close_on_leave"]
            save_config(self.config)
            await interaction.followup.send(f"✅ Fermeture auto {'activée' if self.config['close_on_leave'] else 'désactivée'}.")

    @discord.ui.select(
        placeholder="⚙️ Configurer une option",
        options=[discord.SelectOption(label=f"Option {i+1}", emoji="⚙️") for i in range(5)]
    )
    async def select_option(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.defer()
        option = select.values[0]
        option_index = int(option.split()[-1]) - 1

        # Assurez-vous que l'option existe dans le dictionnaire
        if str(option_index) not in self.config["options"]:
            self.config["options"][str(option_index)] = {
                "category": None,
                "name": f"Option {option_index + 1}",
                "open_message": "Bienvenue dans votre ticket.",
                "mention_role": None,
                "enabled": True
            }

        option_config = self.config["options"][str(option_index)]

        embed = discord.Embed(title=f"⚙ Configuration de {option}", color=0x4193f5)
        embed.add_field(name="Catégorie", value=f"<#{option_config['category']}>" if option_config["category"] else "Non définie", inline=False)
        embed.add_field(name="Nom", value=option_config["name"], inline=False)
        embed.add_field(name="Message d'ouverture", value=option_config["open_message"], inline=False)
        embed.add_field(name="Rôle mentionné", value=f"<@&{option_config['mention_role']}>" if option_config["mention_role"] else "Aucun", inline=False)

        option_view = TicketOptionView(self.ctx, self.config, option_index)
        await interaction.followup.send(embed=embed, view=option_view)

    async def wait_for_response(self, interaction, prompt, key):
        await interaction.followup.send(f"✍️ **{prompt} ?** (Réponds dans ce salon)")

        def check(m):
            return m.author == self.ctx.author and m.channel == self.ctx.channel

        msg = await self.ctx.bot.wait_for("message", check=check)
        if key == "select_channel":
            self.config[key] = int(msg.content.strip("<#>"))
        elif key == "select_message":
            self.config[key] = int(msg.content)
        
        save_config(self.config)
        await msg.delete()
        await interaction.followup.send(f"✅ **{prompt} mis à jour !**")

class TicketOptionView(discord.ui.View):
    def __init__(self, ctx, config, option_index):
        super().__init__(timeout=None)
        self.ctx = ctx
        self.config = config
        self.option_index = str(option_index)

    @discord.ui.select(
        placeholder="🔧 Modifier un paramètre",
        options=[
            discord.SelectOption(label="Modifier la catégorie du ticket", emoji="🏷️"),
            discord.SelectOption(label="Modifier le nom de l'option", emoji="✏️"),
            discord.SelectOption(label="Modifier le message d'ouverture", emoji="📝"),
            discord.SelectOption(label="Modifier le rôle mentionné", emoji="👥")
        ]
    )
    async def select_option_setting(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.defer()
        choice = select.values[0]

        if choice == "Modifier la catégorie du ticket":
            await self.wait_for_response(interaction, "Catégorie", "category")

        elif choice == "Modifier le nom de l'option":
            await self.wait_for_response(interaction, "Nom de l'option", "name")

        elif choice == "Modifier le message d'ouverture":
            await self.wait_for_response(interaction, "Message d'ouverture", "open_message")

        elif choice == "Modifier le rôle mentionné":
            await self.wait_for_response(interaction, "Rôle mentionné", "mention_role")

    async def wait_for_response(self, interaction, prompt, key):
        await interaction.followup.send(f"✍️ **{prompt} ?** (Réponds dans ce salon)")

        def check(m):
            return m.author == self.ctx.author and m.channel == self.ctx.channel

        msg = await self.ctx.bot.wait_for("message", check=check)
        self.config["options"][self.option_index][key] = msg.content
        save_config(self.config)
        await msg.delete()
        await interaction.followup.send(f"✅ **{prompt} mis à jour !**")

    @discord.ui.button(label="❌ Désactiver l'option", style=discord.ButtonStyle.danger)
    async def disable_option(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.config["options"][self.option_index]["enabled"] = False
        save_config(self.config)
        await interaction.response.send_message(f"✅ **Option {self.option_index} désactivée !**", ephemeral=True)
        self.stop()

    @discord.ui.button(label="📤 Envoyer le sélecteur", style=discord.ButtonStyle.green)
    async def send_selector(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = self.ctx.guild.get_channel(self.config.get("select_channel"))
        if channel:
            await channel.send(f"🎫 Sélecteur de tickets !")
            await interaction.response.send_message(f"✅ Sélecteur envoyé dans {channel.mention}", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Salon non défini pour le sélecteur.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(TicketConfig(bot))