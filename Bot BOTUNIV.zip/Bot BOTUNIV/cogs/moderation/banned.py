import discord
from discord.ext import commands
import json

class Ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            for role in ("buyer", "owner"):
                for role_id in roles_data.get(role, {}):
                    if str(user_id) == role_id:
                        return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="ban")
    async def ban(self, ctx, member: discord.Member, *, reason="Aucune raison fournie"):
        """ Bannit un membre avec +ban <id/@membre> [raison] """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            await member.ban(reason=reason)
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission insuffisante",
                description="Je n'ai pas la permission de bannir ce membre.",
                color=0x9884fe
            ))

        embed = discord.Embed(title="🚨 Membre Banni", color=0x9884fe)
        embed.add_field(name="👤 Membre", value=member.mention, inline=False)
        embed.add_field(name="📌 Raison", value=reason, inline=False)
        embed.set_footer(text=f"Banni par {ctx.author}")

        await ctx.send(embed=embed)

    @commands.command(name="unban")
    async def unban(self, ctx, member_id: int):
        """ Débannit un membre avec +unban <id du membre> """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            user = await self.bot.fetch_user(member_id)
            await ctx.guild.unban(user, reason=f"Unban par {ctx.author}")

            embed = discord.Embed(title="🔓 Membre Débanni", color=0x9884fe)
            embed.add_field(name="👤 Membre", value=f"{user.mention} ({user.id})", inline=False)
            embed.set_footer(text=f"Débanni par {ctx.author}")

            await ctx.send(embed=embed)

        except discord.NotFound:
            await ctx.send(embed=discord.Embed(
                title="⚠️ Erreur",
                description=f"Aucun utilisateur avec l'ID `{member_id}` n'a été trouvé dans la liste des bannis.",
                color=0x9884fe
            ))
        except discord.Forbidden:
            await ctx.send(embed=discord.Embed(
                title="⛔ Permission insuffisante",
                description="Je n'ai pas la permission de débannir ce membre.",
                color=0x9884fe
            ))

async def setup(bot):
    await bot.add_cog(Ban(bot))