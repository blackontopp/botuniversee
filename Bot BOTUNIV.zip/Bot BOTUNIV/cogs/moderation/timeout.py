import discord
from discord.ext import commands
import json
import re
from datetime import timedelta

class Timeout(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer, Owner ou Mode dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            for role in ("buyer", "owner", "mode"):
                for role_id in roles_data.get(role, {}):
                    if str(user_id) == role_id:
                        return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="tempmute")
    async def tempmute(self, ctx, member: discord.Member, duration: str, *, reason: str = "Aucune raison fournie"):
        """ Mute temporairement un membre avec +tempmute <id/@membre> <temps> [raison] """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        match = re.match(r"^(\d+)([mhj])$", duration)
        if not match:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Format du temps invalide",
                description="Utilise `5h` (heures), `10m` (minutes), `2j` (jours).",
                color=0x9884fe
            ))

        amount = int(match.group(1))
        unit = match.group(2)

        time_delta = timedelta(hours=amount) if unit == "h" else \
                     timedelta(minutes=amount) if unit == "m" else \
                     timedelta(days=amount) if unit == "j" else None

        if not time_delta:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Durée invalide",
                description="Utilise `5h` (heures), `10m` (minutes), `2j` (jours).",
                color=0x9884fe
            ))

        try:
            await member.timeout(discord.utils.utcnow() + time_delta, reason=reason)
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission insuffisante",
                description="Je n'ai pas la permission de mute ce membre.",
                color=0x9884fe
            ))

        embed = discord.Embed(title="🔇 Membre Muté", color=0x9884fe)
        embed.add_field(name="👤 Membre", value=member.mention, inline=False)
        embed.add_field(name="⏳ Durée", value=duration, inline=False)
        embed.add_field(name="📌 Raison", value=reason, inline=False)
        embed.set_footer(text=f"Muté par {ctx.author}")

        await ctx.send(embed=embed)

    @commands.command(name="unmute")
    async def unmute(self, ctx, member: discord.Member):
        """ Retire un mute d'un membre avec +unmute <id/@membre> """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            await member.timeout(None, reason="Unmute manuel")
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission insuffisante",
                description="Je n'ai pas la permission d'unmute ce membre.",
                color=0x9884fe
            ))

        embed = discord.Embed(title="🔊 Membre Unmuté", color=0x9884fe)
        embed.add_field(name="👤 Membre", value=member.mention, inline=False)
        embed.set_footer(text=f"Unmuté par {ctx.author}")

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Timeout(bot))