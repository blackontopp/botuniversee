import discord
from discord.ext import commands
import json

class Kick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer, Owner ou Mode dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            for role in ("buyer", "owner", "mode"):
                for role_id in roles_data.get(role, {}):
                    if str(user_id) == role_id:
                        return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="kick")
    async def kick(self, ctx, member: discord.Member, *, reason="Aucune raison fournie"):
        """ Expulse un membre avec +kick <id/@membre> [raison] """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            await member.kick(reason=reason)
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission insuffisante",
                description="Je n'ai pas la permission d'expulser ce membre.",
                color=0x9884fe
            ))

        embed = discord.Embed(title="🚨 Membre Expulsé", color=0x9884fe)
        embed.add_field(name="👤 Membre", value=member.mention, inline=False)
        embed.add_field(name="📌 Raison", value=reason, inline=False)
        embed.set_footer(text=f"Expulsé par {ctx.author}")

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Kick(bot))