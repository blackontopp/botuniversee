import discord
from discord.ext import commands
import json

WARN_FILE = "data/warn.json"
ROLES_FILE = "data/roles.json"

# Charger les rôles
def load_roles():
    try:
        with open(ROLES_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Vérifier les permissions (Owner, Buyer, Mode)
def has_permission(user_id):
    """ Vérifie si un utilisateur est Buyer ou Owner ou Mode dans roles.json """
    try:
        with open(ROLES_FILE, 'r') as f:
            roles_data = json.load(f)

        # Vérifie si l'utilisateur est dans les rôles autorisés
        if str(user_id) in roles_data.get("buyer", {}):
            return True
        if str(user_id) in roles_data.get("owner", {}):
            return True
        if str(user_id) in roles_data.get("mode", {}):
            return True
        return False
    except FileNotFoundError:
        return False

# Charger les avertissements
def load_warns(guild_id):
    try:
        with open(WARN_FILE, "r") as f:
            data = json.load(f)
            return data.get(str(guild_id), {})
    except FileNotFoundError:
        return {}

# Sauvegarder les avertissements
def save_warns(guild_id, warns):
    try:
        with open(WARN_FILE, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        data = {}

    data[str(guild_id)] = warns

    with open(WARN_FILE, "w") as f:
        json.dump(data, f, indent=4)

class Warn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="warn", description="Avertir un membre.")
    async def warn(self, ctx, member: discord.Member, *, reason: str):
        # Vérifier les permissions
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        # Charger les avertissements existants
        warns = load_warns(ctx.guild.id)

        # Créer un nouvel avertissement
        if str(member.id) not in warns:
            warns[str(member.id)] = []

        # Ajouter un avertissement avec un index
        warn_index = len(warns[str(member.id)]) + 1
        warns[str(member.id)].append({"index": warn_index, "reason": reason})

        # Sauvegarder les avertissements
        save_warns(ctx.guild.id, warns)

        # Confirmer l'avertissement
        await ctx.send(embed=discord.Embed(
            title="⚠️ Avertissement ajouté",
            description=f"{member.mention} a été averti pour : `{reason}`.",
            color=0x9884fe
        ))

    @commands.command(name="unwarn", description="Retirer un avertissement à un membre.")
    async def unwarn(self, ctx, member: discord.Member, warn_index: int):
        # Vérifier les permissions
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        # Charger les avertissements existants
        warns = load_warns(ctx.guild.id)

        if str(member.id) not in warns or warn_index <= 0 or warn_index > len(warns[str(member.id)]):
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Erreur",
                description=f"Aucun avertissement trouvé pour {member.mention} avec l'index `{warn_index}`.",
                color=0x9884fe
            ))

        # Supprimer l'avertissement spécifié
        warns[str(member.id)].pop(warn_index - 1)

        # Sauvegarder les avertissements
        save_warns(ctx.guild.id, warns)

        # Confirmer le retrait de l'avertissement
        await ctx.send(embed=discord.Embed(
            title="✅ Avertissement retiré",
            description=f"L'avertissement {warn_index} pour {member.mention} a été retiré.",
            color=0x9884fe
        ))

    @commands.command(name="warnlist", description="Voir les avertissements d'un membre.")
    async def warnlist(self, ctx, member: discord.Member):
        # Vérifier les permissions
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        # Charger les avertissements existants
        warns = load_warns(ctx.guild.id)

        if str(member.id) not in warns or not warns[str(member.id)]:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Avertissements",
                description=f"{member.mention} n'a aucun avertissement.",
                color=0x9884fe
            ))

        # Créer une liste des avertissements
        warn_list = "\n".join([f"**{warn['index']}**: {warn['reason']}" for warn in warns[str(member.id)]])

        # Afficher la liste des avertissements
        await ctx.send(embed=discord.Embed(
            title=f"⚠️ Avertissements de {member.mention}",
            description=warn_list,
            color=0x9884fe
        ))

async def setup(bot):
    await bot.add_cog(Warn(bot))