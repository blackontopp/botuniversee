import discord
from discord.ext import commands
import json

BLACKLIST_FILE = "data/blacklist.json"
ROLES_FILE = "data/roles.json"

# Charger les rôles
def load_roles():
    try:
        with open(ROLES_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Vérifier les permissions (Owner ou Buyer)
def has_permission(user_id):
    """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json """
    try:
        with open(ROLES_FILE, 'r') as f:
            roles_data = json.load(f)

        # Vérifie si l'utilisateur est dans les rôles autorisés
        if str(user_id) in roles_data.get("buyer", {}):
            return True
        if str(user_id) in roles_data.get("owner", {}):
            return True
        return False
    except FileNotFoundError:
        return False

# Charger la blacklist
def load_blacklist():
    try:
        with open(BLACKLIST_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

class Blacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="bl", description="Ajoute un membre à la blacklist ou montre la liste des membres blacklistés.")
    async def blacklist(self, ctx, member: discord.Member = None, *, reason: str = None):
        # Vérifier si l'utilisateur a les bonnes permissions (Owner ou Buyer)
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        # Si aucun membre n'est mentionné, on affiche la liste des membres blacklistés
        if member is None:
            blacklist = load_blacklist()
            if not blacklist:
                return await ctx.send(embed=discord.Embed(
                    title="🔴 Liste des membres blacklistés",
                    description="Il n'y a actuellement aucun membre dans la blacklist.",
                    color=0x9884fe
                ))
            
            embed = discord.Embed(
                title="🔴 Liste des membres blacklistés",
                description="\n".join([f"{member_id}: {details['reason']}" for member_id, details in blacklist.items()]),
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Ajouter un membre à la blacklist
        blacklist = load_blacklist()

        if str(member.id) in blacklist:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Ce membre est déjà blacklisté",
                description=f"{member.mention} est déjà dans la blacklist.",
                color=0x9884fe
            ))

        if not reason:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Raison requise",
                description="Tu dois fournir une raison pour ajouter ce membre à la blacklist.",
                color=0x9884fe
            ))

        # Ajouter le membre à la blacklist
        blacklist[str(member.id)] = {"reason": reason}

        with open(BLACKLIST_FILE, "w") as f:
            json.dump(blacklist, f)

        # Bannir le membre
        try:
            await member.ban(reason=reason)
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="❌ Erreur de permission",
                description="Je n'ai pas la permission de bannir ce membre.",
                color=0x9884fe
            ))

        # Confirmer l'ajout à la blacklist
        await ctx.send(embed=discord.Embed(
            title="🔴 Membre ajouté à la blacklist",
            description=f"{member.mention} a été ajouté à la blacklist pour la raison : `{reason}`.",
            color=0x9884fe
        ))

    @commands.command(name="unbl", description="Retire un membre de la blacklist.")
    async def unblacklist(self, ctx, member: discord.Member):
        # Vérifier si l'utilisateur a les bonnes permissions (Owner ou Buyer)
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        blacklist = load_blacklist()

        if str(member.id) not in blacklist:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Ce membre n'est pas dans la blacklist",
                description=f"{member.mention} n'est pas dans la blacklist.",
                color=0x9884fe
            ))

        # Retirer le membre de la blacklist
        del blacklist[str(member.id)]

        with open(BLACKLIST_FILE, "w") as f:
            json.dump(blacklist, f)

        # Débannir le membre
        try:
            await member.unban()
        except discord.Forbidden:
            return await ctx.send(embed=discord.Embed(
                title="❌ Erreur de permission",
                description="Je n'ai pas la permission de débannir ce membre.",
                color=0x9884fe
            ))

        # Confirmer le retrait de la blacklist
        await ctx.send(embed=discord.Embed(
            title="✅ Membre retiré de la blacklist",
            description=f"{member.mention} a été retiré de la blacklist.",
            color=0x9884fe
        ))

async def setup(bot):
    await bot.add_cog(Blacklist(bot))