import discord
from discord.ext import commands
import json

class Presence(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            for buyer_id in roles_data.get("buyer", {}):
                if str(user_id) == buyer_id:
                    return True

            for owner_id in roles_data.get("owner", {}):
                if str(user_id) == owner_id:
                    return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="presence")
    async def change_presence(self, ctx, status: str):
        """ Change la présence du bot (online, dnd, idle, offline) """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        statuses = {
            "online": discord.Status.online,
            "dnd": discord.Status.dnd,
            "idle": discord.Status.idle,
            "offline": discord.Status.offline
        }

        if status.lower() not in statuses:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Statut invalide",
                description="Statuts disponibles : `online`, `dnd`, `idle`, `offline`.",
                color=0x9884fe
            ))

        await self.bot.change_presence(status=statuses[status.lower()])
        await ctx.send(embed=discord.Embed(
            title="✅ Présence mise à jour",
            description=f"Le bot est maintenant en statut `{status.lower()}`.",
            color=0x9884fe
        ))

    @commands.command(name="activity")
    async def change_activity(self, ctx, activity_type: str, *, message: str):
        """ Change l'activité du bot (stream, playing, watch) """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        activities = {
            "stream": discord.Streaming(name=message, url="https://discord.gg/hZ5MhbXkyc"),
            "playing": discord.Game(name=message),
            "watch": discord.Activity(type=discord.ActivityType.watching, name=message)
        }

        if activity_type.lower() not in activities:
            return await ctx.send(embed=discord.Embed(
                title="⚠️ Type d'activité invalide",
                description="Types disponibles : `stream`, `playing`, `watch`.",
                color=0x9884fe
            ))

        await self.bot.change_presence(activity=activities[activity_type.lower()])
        await ctx.send(embed=discord.Embed(
            title="✅ Activité mise à jour",
            description=f"Le bot est maintenant en `{activity_type.lower()}` avec le message : `{message}`.",
            color=0x9884fe
        ))

async def setup(bot):
    await bot.add_cog(Presence(bot))