import discord
import json
from discord.ext import commands

class NewServer(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        """Quand le bot rejoint un serveur, il envoie un MP au Buyer avec les infos du serveur."""
        print(f"Le bot a rejoint un serveur : {guild.name} (ID: {guild.id})")

        # Récupérer les données des rôles
        roles_data = self._get_roles_data()
        if "buyer" not in roles_data or not roles_data["buyer"]:
            print("Aucun Buyer défini dans roles.json.")
            return
        
        buyer_id = next(iter(roles_data["buyer"]))  # Prend le premier Buyer
        buyer_user = await self.bot.fetch_user(int(buyer_id))

        await self.send_new_server_message(buyer_user, guild)

    async def send_new_server_message(self, buyer_user, guild):
        """Envoie un MP au Buyer avec les infos du serveur."""
        owner = guild.owner
        server_icon = guild.icon.url if guild.icon else "https://cdn.discordapp.com/embed/avatars/0.png"

        embed = discord.Embed(
            title="📢 Le bot a rejoint un nouveau serveur !",
            description=f"Le bot vient de rejoindre **{guild.name}** ! 🎉",
            color=0x9884fe,
            timestamp=discord.utils.utcnow()
        )
        embed.set_thumbnail(url=server_icon)
        embed.add_field(name="🏷️ Nom du serveur", value=guild.name, inline=False)
        embed.add_field(name="🆔 ID du serveur", value=guild.id, inline=False)
        embed.add_field(name="👑 Propriétaire", value=f"{owner} (`{owner.id}`)", inline=False)
        embed.add_field(name="👥 Nombre de membres", value=f"{guild.member_count} membres", inline=False)
        embed.set_footer(text="SupportBot V2 | Gestion des serveurs")

        try:
            await buyer_user.send(embed=embed)
        except discord.Forbidden:
            print(f"Impossible d'envoyer un MP au Buyer ({buyer_user.name}).")

    def _get_roles_data(self):
        """Récupère les rôles depuis roles.json"""
        try:
            with open('data/roles.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

# Setup du cog
async def setup(bot):
    await bot.add_cog(NewServer(bot))