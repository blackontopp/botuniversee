import discord
from discord.ext import commands
import json

class ServerManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifie si l'utilisateur est Buyer
            for buyer_id in roles_data.get("buyer", {}):
                if str(user_id) == buyer_id:
                    return True

            # Vérifie si l'utilisateur est Owner
            for owner_id in roles_data.get("owner", {}):
                if str(user_id) == owner_id:
                    return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="serveurs")
    async def list_servers(self, ctx):
        """ Affiche la liste des serveurs où le bot est, avec une invitation pour chaque """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        embed = discord.Embed(title="📜 Liste des serveurs", color=0x9884fe)

        for guild in self.bot.guilds:
            invite = "Aucune invitation disponible"
            for channel in guild.text_channels:
                if channel.permissions_for(guild.me).create_instant_invite:
                    invite = await channel.create_invite(max_age=0, max_uses=0)
                    invite = invite.url
                    break

            embed.add_field(
                name=f"{guild.name} (`{guild.id}`)",  # Ajout de l'ID du serveur
                value=f"🔗 [Invitation]({invite})",
                inline=False
            )

        await ctx.send(embed=embed)

    @commands.command(name="leave")
    async def leave_server(self, ctx, server_id: int):
        """ Quitte un serveur spécifique """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        guild = self.bot.get_guild(server_id)
        if not guild:
            return await ctx.send(embed=discord.Embed(
                title="❌ Serveur introuvable",
                description=f"Le bot n'est pas sur le serveur avec l'ID `{server_id}`.",
                color=0x9884fe
            ))

        await guild.leave()
        await ctx.send(embed=discord.Embed(
            title="✅ Départ effectué",
            description=f"Le bot a quitté `{guild.name}` (`{server_id}`).",
            color=0x9884fe
        ))

async def setup(bot):
    await bot.add_cog(ServerManager(bot))