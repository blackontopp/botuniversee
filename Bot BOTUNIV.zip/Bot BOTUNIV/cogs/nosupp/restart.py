import discord
from discord.ext import commands
import os
import sys
import json

# Fonction pour vérifier si un utilisateur est dans un rôle spécifique (BUYER, OWNER)
def has_role(user_id, role):
    try:
        with open('data/roles.json', 'r') as f:
            roles_data = json.load(f)
        # Ajouter un log pour vérifier que l'ID est bien dans la liste
        print(f"Vérification pour {role}: {user_id} dans {roles_data.get(role, [])}")
        return str(user_id) in roles_data.get(role, [])
    except FileNotFoundError:
        return False

class Restart(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def restart(self, ctx):
        """Redémarre le bot. Accessible uniquement par les membres BUYER et OWNER."""
        # Vérifier si l'utilisateur est un BUYER ou un OWNER
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'utiliser cette commande.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        # Créer un embed pour notifier le redémarrage
        embed = discord.Embed(
            title="🔄 Redémarrage du bot",
            description="Le bot est en cours de redémarrage... Veuillez patienter.",
            color=0x9884fe
        )
        embed.set_footer(text="SupportBot V2 | Redémarrage")
        await ctx.send(embed=embed)

        # Effectuer un redémarrage du bot
        os.execv(sys.executable, ['python'] + sys.argv)  # Redémarre le bot

# Ajout du cog à votre bot avec async/await dans setup
async def setup(bot):
    await bot.add_cog(Restart(bot))