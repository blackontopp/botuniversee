import discord
from discord.ext import commands
import json
import aiohttp

ROLES_FILE = "data/roles.json"

# Vérifier les permissions (Owner, Buyer)
def has_permission(user_id):
    """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json """
    try:
        with open(ROLES_FILE, 'r') as f:
            roles_data = json.load(f)

        # Vérifie si l'utilisateur est dans les rôles autorisés
        if str(user_id) in roles_data.get("buyer", {}):
            return True
        if str(user_id) in roles_data.get("owner", {}):
            return True
        return False
    except FileNotFoundError:
        return False

class Personalization(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="setname", description="Changer le nom du bot.")
    async def setname(self, ctx, *, new_name: str):
        # Vérifier les permissions
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            # Changer le nom du bot
            await self.bot.user.edit(username=new_name)
            await ctx.send(embed=discord.Embed(
                title="✅ Nom du bot changé",
                description=f"Le nom du bot a été changé en : `{new_name}`.",
                color=0x9884fe
            ))
        except discord.Forbidden:
            await ctx.send(embed=discord.Embed(
                title="❌ Erreur",
                description="Je n'ai pas la permission de changer le nom du bot.",
                color=0x9884fe
            ))

    @commands.command(name="setphoto", description="Changer la photo de profil du bot.")
    async def setphoto(self, ctx, photo_url: str):
        # Vérifier les permissions
        if not has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            # Vérifier si l'URL est valide
            async with aiohttp.ClientSession() as session:
                async with session.head(photo_url) as response:
                    if response.status != 200:
                        return await ctx.send(embed=discord.Embed(
                            title="❌ URL invalide",
                            description="L'URL fournie n'est pas valide ou inaccessible.",
                            color=0x9884fe
                        ))

            # Changer la photo de profil du bot
            await self.bot.user.edit(avatar=photo_url)
            await ctx.send(embed=discord.Embed(
                title="✅ Photo de profil changée",
                description="La photo de profil du bot a été changée.",
                color=0x9884fe
            ))
        except discord.Forbidden:
            await ctx.send(embed=discord.Embed(
                title="❌ Erreur",
                description="Je n'ai pas la permission de changer la photo de profil du bot.",
                color=0x9884fe
            ))
        except Exception as e:
            await ctx.send(embed=discord.Embed(
                title="❌ Erreur inconnue",
                description=f"Une erreur est survenue : {str(e)}",
                color=0x9884fe
            ))

async def setup(bot):
    await bot.add_cog(Personalization(bot))