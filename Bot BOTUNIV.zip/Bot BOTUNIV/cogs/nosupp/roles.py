import discord
from discord.ext import commands
import json
import os

ROLES_FILE = "data/roles.json"

def load_roles():
    """Charge les rôles depuis le fichier JSON ou renvoie un dict vide si inexistant."""
    if not os.path.exists(ROLES_FILE):
        return {}

    with open(ROLES_FILE, "r") as file:
        return json.load(file)

def save_roles(data):
    """Sauvegarde les rôles dans le fichier JSON."""
    with open(ROLES_FILE, "w") as file:
        json.dump(data, file, indent=4)

def add_role(user_id: int, role: str):
    """Ajoute un membre à un rôle spécifique."""
    roles = load_roles()
    if role not in roles:
        roles[role] = []

    if str(user_id) not in roles[role]:
        roles[role].append(str(user_id))
        save_roles(roles)

def remove_role(user_id: int, role: str):
    """Retire un membre d'un rôle spécifique."""
    roles = load_roles()
    if role in roles and str(user_id) in roles[role]:
        roles[role].remove(str(user_id))
        if not roles[role]:
            del roles[role]
        save_roles(roles)

def has_role(user_id: int, role: str):
    """Vérifie si un membre a un rôle."""
    roles = load_roles()
    return role in roles and str(user_id) in roles[role]

class Roles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def owner(self, ctx, member: discord.Member = None):
        """Ajoute un Owner ou affiche la liste des Owners."""
        roles = load_roles()

        if member is None:
            # Seuls les membres buyer peuvent voir la liste des owners
            if not has_role(ctx.author.id, "buyer"):
                embed = discord.Embed(description="❌ **Tu n'as pas la permission de voir la liste des Owners.**", color=0x9884fe)
                await ctx.send(embed=embed)
                return

            owners = roles.get("owner", [])
            owner_list = "\n".join(f"<@{o}>" for o in owners) if owners else "Aucun Owner."
            embed = discord.Embed(title="📜 Liste des Owners", description=owner_list, color=0x9884fe)
            await ctx.send(embed=embed)
            return

        # Seuls les membres buyer peuvent ajouter un member en tant qu'Owner
        if not has_role(ctx.author.id, "buyer"):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'ajouter un Owner.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        add_role(member.id, "owner")
        embed = discord.Embed(description=f"✅ **{member.mention} a été ajouté en tant qu'Owner !**", color=0x9884fe)
        await ctx.send(embed=embed)

    @commands.command()
    async def unowner(self, ctx, member: discord.Member):
        """Retire un Owner (réservé aux Buyers)."""
        if not has_role(ctx.author.id, "buyer"):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission de retirer un Owner.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        if not has_role(member.id, "owner"):
            embed = discord.Embed(description="⚠️ **Ce membre n'est pas Owner.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        remove_role(member.id, "owner")
        embed = discord.Embed(description=f"✅ **{member.mention} n'est plus Owner.**", color=0x9884fe)
        await ctx.send(embed=embed)

    @commands.command()
    async def mode(self, ctx, member: discord.Member = None):
        """Ajoute un Mode ou affiche la liste des Modes."""
        roles = load_roles()

        if member is None:
            # Seuls les membres buyer et owner peuvent voir la liste des modes
            if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
                embed = discord.Embed(description="❌ **Tu n'as pas la permission de voir la liste des Modes.**", color=0x9884fe)
                await ctx.send(embed=embed)
                return

            modes = roles.get("mode", [])
            mode_list = "\n".join(f"<@{m}>" for m in modes) if modes else "Aucun Mode."
            embed = discord.Embed(title="📜 Liste des Modes", description=mode_list, color=0x9884fe)
            await ctx.send(embed=embed)
            return

        # Seuls les membres buyer et owner peuvent ajouter un member en tant que Mode
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission d'ajouter un Mode.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        add_role(member.id, "mode")
        embed = discord.Embed(description=f"✅ **{member.mention} a été ajouté en tant que Mode !**", color=0x9884fe)
        await ctx.send(embed=embed)

    @commands.command()
    async def unmode(self, ctx, member: discord.Member):
        """Retire un Mode (réservé aux Buyers et Owners)."""
        if not (has_role(ctx.author.id, "buyer") or has_role(ctx.author.id, "owner")):
            embed = discord.Embed(description="❌ **Tu n'as pas la permission de retirer un Mode.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        if not has_role(member.id, "mode"):
            embed = discord.Embed(description="⚠️ **Ce membre n'est pas Mode.**", color=0x9884fe)
            await ctx.send(embed=embed)
            return

        remove_role(member.id, "mode")
        embed = discord.Embed(description=f"✅ **{member.mention} n'est plus Mode.**", color=0x9884fe)
        await ctx.send(embed=embed)

# Ajout du cog à votre bot
async def setup(bot):
    await bot.add_cog(Roles(bot))