import discord
from discord.ext import commands
import datetime

class ServeurInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def serveurinfo(self, ctx):
        """Commande qui renvoie des infos sur le serveur avec des emojis !"""
        
        # Récupérer la date de création du serveur (c'est un datetime aware)
        created_at = ctx.guild.created_at

        # Assurer que `created_at` est converti en naive datetime (en UTC)
        created_at_naive = created_at.replace(tzinfo=None)

        # Calculer la différence de temps (delta)
        delta = datetime.datetime.utcnow() - created_at_naive

        # Créer l'embed avec des emojis et des informations stylisées
        embed = discord.Embed(
            title=f"Informations sur le serveur : {ctx.guild.name} 🏰",
            description=f"Voici quelques informations importantes sur **{ctx.guild.name}** !",
            color=0x9884fe,  # Couleur SupportBot
            timestamp=discord.utils.utcnow()
        )
        
        embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else ctx.guild.owner.avatar.url)
        embed.set_footer(text="SupportBot V2 | En ligne")

        # Ajout des champs avec des emojis
        embed.add_field(name="📝 **Nom du serveur**", value=ctx.guild.name, inline=False)
        embed.add_field(name="🆔 **ID du serveur**", value=ctx.guild.id, inline=False)
        embed.add_field(name="👥 **Membres**", value=f"{len(ctx.guild.members)} membres", inline=False)
        embed.add_field(name="📅 **Serveur créé le**", value=f"{created_at.strftime('%d %b %Y, %H:%M:%S')} UTC", inline=False)
        embed.add_field(name="⏳ **Temps depuis la création**", value=str(delta).split(".")[0], inline=False)
        embed.add_field(name="🎮 **Activité actuelle**", value=f"Regarde `SupportBot V2 #soon`", inline=False)
        embed.add_field(name="👑 **Propriétaire**", value=ctx.guild.owner.mention, inline=False)

        # Envoi de l'embed dans le salon
        await ctx.send(embed=embed)

# Cette fonction doit être utilisée pour ajouter le cog à ton bot
async def setup(bot):
    await bot.add_cog(ServeurInfo(bot))