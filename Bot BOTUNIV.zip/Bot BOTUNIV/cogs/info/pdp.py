import discord
from discord.ext import commands

class ProfilePictures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="avatar")
    async def avatar_cmd(self, ctx, member: discord.Member = None):
        """Affiche l'avatar d'un membre"""
        member = member or ctx.author  # Si aucun membre mentionné, afficher le sien

        embed = discord.Embed(
            title=f"🖼️ Avatar de {member.name}",
            color=0x9884fe
        )
        embed.set_image(url=member.display_avatar.url)
        embed.set_footer(text=f"Demandé par {ctx.author}", icon_url=ctx.author.display_avatar.url)

        await ctx.send(embed=embed)

    @commands.command(name="baniere")
    async def banner_cmd(self, ctx, member: discord.Member = None):
        """Affiche la bannière d'un membre"""
        member = member or ctx.author  # Si aucun membre mentionné, afficher la sienne

        user = await self.bot.fetch_user(member.id)  # Récupérer les données complètes du membre

        if user.banner:
            embed = discord.Embed(
                title=f"🎨 Bannière de {member.name}",
                color=0x9884fe
            )
            embed.set_image(url=user.banner.url)
        else:
            embed = discord.Embed(
                title="🚫 Aucune bannière",
                description=f"{member.mention} **n'a pas de bannière définie.**",
                color=0x9884fe
            )

        embed.set_footer(text=f"Demandé par {ctx.author}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ProfilePictures(bot))