import discord
from discord.ext import commands
from discord.ext.commands import Context

class UserInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def userinfo(self, ctx: Context, member: discord.Member = None):
        """Commande qui renvoie les infos sur l'utilisateur ou un autre membre"""
        
        # Si aucun membre n'est mentionné, on utilise l'auteur de la commande
        if not member:
            member = ctx.author

        # Créer l'embed pour afficher les informations de l'utilisateur
        embed = discord.Embed(
            title=f"Informations sur l'utilisateur : {member.name}#{member.discriminator} 👤",
            description=f"Voici les informations de **{member.name}** !",
            color=0x9884fe,  # Couleur SupportBot
            timestamp=discord.utils.utcnow()
        )

        embed.set_thumbnail(url=member.avatar.url)  # Avatar de l'utilisateur
        embed.set_footer(text="SupportBot V2 | En ligne")

        # Ajouter des informations sur le membre
        embed.add_field(name="🆔 **ID du membre**", value=member.id, inline=False)
        embed.add_field(name="📅 **Compte créé le**", value=member.created_at.strftime("%d %b %Y, %H:%M:%S UTC"), inline=False)
        embed.add_field(name="🌍 **Rejoint le serveur le**", value=member.joined_at.strftime("%d %b %Y, %H:%M:%S UTC"), inline=False)
        embed.add_field(name="👥 **Status**", value=str(member.status).capitalize(), inline=True)
        embed.add_field(name="🎮 **Activité actuelle**", value=str(member.activity) if member.activity else "Aucune activité", inline=True)
        embed.add_field(name="💬 **Rôle principal**", value=member.top_role.mention, inline=False)

        # Envoyer l'embed avec les informations
        await ctx.send(embed=embed)

# Cette fonction doit être utilisée pour ajouter le cog à ton bot
async def setup(bot):
    await bot.add_cog(UserInfo(bot))