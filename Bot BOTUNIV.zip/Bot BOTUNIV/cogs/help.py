import discord
from discord.ext import commands

class HelpCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", aliases=["aide"])
    async def help_command(self, ctx):
        """Affiche le menu d'aide avec les catégories"""

        embed = discord.Embed(
            title="📚 Menu d'aide",
            description="Sélectionnez une catégorie pour afficher les commandes correspondantes.",
            color=0x9884fe  # Couleur SupportBot
        )
        embed.set_footer(text="SupportBot | Système d'aide")

        view = HelpSelectView()
        await ctx.send(embed=embed, view=view)

class HelpSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.select(
        placeholder="Choisissez une catégorie...",
        options=[
            discord.SelectOption(label="🛠️ Modération", value="moderation", description="Commandes de modération"),
            discord.SelectOption(label="🔍 Informations", value="info", description="Commandes d'information"),
            discord.SelectOption(label="🛠️ Utilitaires", value="utils", description="Commandes utiles"),
            discord.SelectOption(label="🎭 Autres", value="autres", description="Commandes diverses"),
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        category = select.values[0]
        embed = discord.Embed(color=0x9884fe)  # Couleur SupportBot

        if category == "moderation":
            embed.title = "🛠️ Commandes de Modération"
            embed.description = """
            `warn` - Avertir un utilisateur.
            `ban` - Bannir un utilisateur.
            `unban` - Débannir un utilisateur.
            `kick` - Expulser un utilisateur.
            `tempmute` - Rendre muet temporairement.
            `unmute` - Rendre la parole à un utilisateur.
            `lock` - Verrouiller un salon.
            `unlock` - Déverrouiller un salon.
            `massivelock` - Verrouiller plusieurs salons.
            `massivehide` - Cacher plusieurs salons.
            """

        elif category == "info":
            embed.title = "🔍 Commandes d'Information"
            embed.description = """
            `userinfo` - Affiche les infos d'un utilisateur.
            `serveurinfo` - Affiche les infos du serveur.
            `avatar` - Affiche l'avatar d'un utilisateur.
            `baniere` - Affiche la bannière d'un utilisateur.
            `activity` - Affiche l'activité d'un utilisateur.
            `presence` - Affiche la présence d'un utilisateur.
            """

        elif category == "utils":
            embed.title = "🛠️ Commandes Utilitaires"
            embed.description = """
            `ping` - Affiche la latence du bot.
            `mp` - Envoyer un message privé.
            `clear` - Supprimer des messages.
            `say` - Faire parler le bot.
            `embed` - Créer un embed.
            `restart` - Redémarrer le bot.
            `setname` - Modifier le pseudo du bot.
            `setphoto` - Modifier la photo du bot.
            `owner` - Définir un propriétaire.
            `unowner` - Retirer un propriétaire.
            """

        elif category == "autres":
            embed.title = "🎭 Autres Commandes"
            embed.description = """
            `suggest-config` - Configurer les suggestions.
            `suggestion` - Envoyer une suggestion.
            `mode` - Activer un mode spécial.
            `unmode` - Désactiver un mode spécial.
            `addrole` - Ajouter un rôle.
            `delrole` - Supprimer un rôle.
            `bl` - Ajouter à la blacklist.
            `unbl` - Retirer de la blacklist.
            `snipe` - Voir un message supprimé.
            `renew` - Renouveler un salon.
            """

        await interaction.response.edit_message(embed=embed)

async def setup(bot):
    await bot.add_cog(HelpCommand(bot))