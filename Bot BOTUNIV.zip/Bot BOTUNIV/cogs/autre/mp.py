import discord
from discord.ext import commands
import json

class MP(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_permission(self, user_id):
        """ Vérifie si un utilisateur est Buyer ou Owner dans roles.json sans [] """
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifie si l'utilisateur est Buyer
            for buyer_id in roles_data.get("buyer", {}):
                if str(user_id) == buyer_id:
                    return True

            # Vérifie si l'utilisateur est Owner
            for owner_id in roles_data.get("owner", {}):
                if str(user_id) == owner_id:
                    return True

            return False
        except FileNotFoundError:
            return False

    @commands.command(name="mp")
    async def send_private_message(self, ctx, member: discord.User, *, message: str):
        """ Envoie un MP à un utilisateur """
        if not self.has_permission(ctx.author.id):
            return await ctx.send(embed=discord.Embed(
                title="⛔ Permission refusée",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            ))

        try:
            await member.send(embed=discord.Embed(
                title="📩 Nouveau Message",
                description=f"**Message de {ctx.author.mention} :**\n\n{message}",
                color=0x9884fe
            ))
            await ctx.send(embed=discord.Embed(
                title="✅ Message envoyé",
                description=f"Le message a été envoyé à {member.mention}.",
                color=0x9884fe
            ))
        except discord.Forbidden:
            await ctx.send(embed=discord.Embed(
                title="❌ Impossible d'envoyer le message",
                description=f"{member.mention} a ses MP fermés.",
                color=0x9884fe
            ))

async def setup(bot):
    await bot.add_cog(MP(bot))