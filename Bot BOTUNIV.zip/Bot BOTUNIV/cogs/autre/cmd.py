import discord
from discord.ext import commands

class CmdList(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def cmd(self, ctx):
        """Commande qui liste le nombre de commandes et leurs noms"""
        
        # Obtenir la liste de toutes les commandes disponibles
        commands_list = [command.name for command in self.bot.commands]
        
        # Créer l'embed pour afficher les commandes et leur nombre
        embed = discord.Embed(
            title="Liste des commandes disponibles 📜",
            description=f"Voici la liste des commandes disponibles pour **{self.bot.user.name}** !",
            color=0x9884fe,
            timestamp=discord.utils.utcnow()
        )

        embed.add_field(name="Nombre total de commandes", value=len(commands_list), inline=False)
        embed.add_field(name="Commandes", value="\n".join(commands_list), inline=False)

        # Envoyer l'embed dans le salon
        await ctx.send(embed=embed)

# Cette fonction doit être utilisée pour ajouter le cog à ton bot
async def setup(bot):
    await bot.add_cog(CmdList(bot))