import discord
from discord.ext import commands
import json

# Dictionnaire pour stocker les derniers messages supprimés par salon
deleted_messages = {}

class Snipe(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """ Enregistre le dernier message supprimé dans un salon """
        if message.guild:
            deleted_messages[message.guild.id, message.channel.id] = message

    @commands.command(name="snipe", description="Voir le dernier message supprimé.")
    async def snipe(self, ctx, channel: discord.TextChannel = None):
        """ Montre le dernier message supprimé d'un salon (optionnel) """
        # Si aucun salon n'est précisé, utilise le salon actuel
        if not channel:
            channel = ctx.channel

        # Récupérer le dernier message supprimé du salon
        deleted_message = deleted_messages.get((ctx.guild.id, channel.id))

        if deleted_message:
            embed = discord.Embed(
                title="Dernier message supprimé",
                description=deleted_message.content,
                color=0x9884fe
            )
            embed.add_field(name="Auteur", value=deleted_message.author.mention)
            embed.set_footer(text=f"Message supprimé dans {channel.name}")
            await ctx.send(embed=embed)
        else:
            await ctx.send(embed=discord.Embed(
                title="❌ Aucun message supprimé récemment",
                description=f"Aucun message n'a été supprimé dans le salon {channel.name}.",
                color=0x9884fe
            ))

async def setup(bot):
    await bot.add_cog(Snipe(bot))