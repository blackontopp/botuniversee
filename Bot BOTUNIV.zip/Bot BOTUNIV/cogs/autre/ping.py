import discord
from discord.ext import commands
import time

class PingView(discord.ui.View):
    """Vue avec un bouton pour actualiser la latence"""
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Actualiser", style=discord.ButtonStyle.gray, emoji="🔄")
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Actualise la latence quand on appuie sur le bouton"""
        start_time = time.perf_counter()
        await interaction.response.defer()  # On évite le "Réfléchit..."
        latency = round((time.perf_counter() - start_time) * 1000, 2)

        # Créer un nouvel embed avec la latence actualisée
        embed = discord.Embed(
            title="🏓 Pong !",
            description=f"**Latence du bot :** `{round(self.bot.latency * 1000, 2)} ms`\n"
                        f"**Temps de réponse :** `{latency} ms`",
            color=0x9884fe,
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text="SupportBot V2 | Latence mise à jour")
        
        # Modifier l'embed du message d'origine
        await interaction.message.edit(embed=embed, view=self)

class Ping(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        """Commande pour voir la latence du bot"""
        latency = round(self.bot.latency * 1000, 2)

        # Créer l'embed
        embed = discord.Embed(
            title="🏓 Pong !",
            description=f"**Latence du bot :** `{latency} ms`",
            color=0x9884fe,
            timestamp=discord.utils.utcnow()
        )
        embed.set_footer(text="SupportBot V2 | Vérification de la latence")

        # Envoyer l'embed avec le bouton d'actualisation
        view = PingView(self.bot)
        await ctx.send(embed=embed, view=view)

# Ajouter le cog au bot
async def setup(bot):
    await bot.add_cog(Ping(bot))