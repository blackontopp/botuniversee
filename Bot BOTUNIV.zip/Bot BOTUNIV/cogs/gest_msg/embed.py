import discord
from discord.ext import commands
import json

class EmbedBuilder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.embed_config = {}  # Stockage temporaire des configurations d'embed

    async def has_permission(self, ctx):
        """Vérifie si l'utilisateur est Buyer ou Owner"""
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            user_id = str(ctx.author.id)
            return any(user_id in users for role, users in roles_data.items() if role in ['buyer', 'owner'])
        except FileNotFoundError:
            return False

    @commands.command(name="embed")
    async def embed_cmd(self, ctx):
        """Commande pour créer un embed personnalisé avec un sélecteur et un bouton"""
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Créer un embed de base
        embed = discord.Embed(
            title="Titre de l'embed",
            description="Description ici...",
            color=0x9884fe
        )
        embed.set_footer(text="Footer ici...")

        # Stocker temporairement la config de l'embed
        self.embed_config[ctx.author.id] = embed

        # Sélecteur pour modifier l'embed
        select = discord.ui.Select(
            placeholder="Modifier l'embed...",
            options=[
                discord.SelectOption(label="Titre", description="Modifier le titre"),
                discord.SelectOption(label="Description", description="Modifier la description"),
                discord.SelectOption(label="Couleur", description="Modifier la couleur"),
                discord.SelectOption(label="Footer", description="Modifier le footer")
            ]
        )

        async def select_callback(interaction: discord.Interaction):
            if interaction.user.id != ctx.author.id:
                return await interaction.response.send_message("Tu ne peux pas modifier cet embed !", ephemeral=True)

            await interaction.response.send_message(f"✍️ Envoie le nouveau {select.values[0]}...", ephemeral=True)

            try:
                msg = await self.bot.wait_for(
                    "message", check=lambda m: m.author == ctx.author and m.channel == ctx.channel, timeout=60
                )
                await msg.delete()  # Supprime le message de configuration
            except TimeoutError:
                return await ctx.send("⏳ Temps écoulé. Réessaie la commande.")

            if select.values[0] == "Titre":
                self.embed_config[ctx.author.id].title = msg.content
            elif select.values[0] == "Description":
                self.embed_config[ctx.author.id].description = msg.content
            elif select.values[0] == "Couleur":
                try:
                    self.embed_config[ctx.author.id].color = int(msg.content.replace("#", ""), 16)
                except ValueError:
                    return await ctx.send("🚨 Couleur invalide ! Utilise un code hexadécimal (ex: `#ff0000`).")
            elif select.values[0] == "Footer":
                self.embed_config[ctx.author.id].set_footer(text=msg.content)

            await embed_msg.edit(embed=self.embed_config[ctx.author.id])

        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)

        # Bouton pour envoyer l'embed
        button = discord.ui.Button(label="📤 Envoyer l'embed", style=discord.ButtonStyle.primary)

        async def button_callback(interaction: discord.Interaction):
            if interaction.user.id != ctx.author.id:
                return await interaction.response.send_message("Tu ne peux pas utiliser ce bouton !", ephemeral=True)

            # Liste des salons pour choisir où envoyer l'embed
            channel_select = discord.ui.Select(
                placeholder="Choisir un salon...",
                options=[
                    discord.SelectOption(label=channel.name, value=str(channel.id))
                    for channel in ctx.guild.text_channels
                ]
            )

            async def channel_callback(interaction: discord.Interaction):
                target_channel = self.bot.get_channel(int(channel_select.values[0]))
                await target_channel.send(embed=self.embed_config[ctx.author.id])
                await interaction.response.send_message(f"✅ Embed envoyé dans {target_channel.mention} !", ephemeral=True)

            channel_select.callback = channel_callback

            view = discord.ui.View()
            view.add_item(channel_select)
            await interaction.response.send_message("📢 Sélectionne le salon où envoyer l'embed :", view=view, ephemeral=True)

        button.callback = button_callback
        view.add_item(button)

        embed_msg = await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(EmbedBuilder(bot))