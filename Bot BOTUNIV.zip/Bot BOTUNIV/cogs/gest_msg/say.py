import discord
from discord.ext import commands
import json

class Say(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Vérifier si l'utilisateur a le rôle 'buyer' ou 'owner' en utilisant le fichier roles.json
    async def has_permission(self, ctx):
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifier si l'utilisateur est dans les rôles 'buyer' ou 'owner' en fonction du fichier
            user_id = str(ctx.author.id)

            for role, users in roles_data.items():
                if user_id in users:
                    if role in ['buyer', 'owner']:  # Vérification si l'utilisateur est buyer ou owner
                        return True
            return False
        except FileNotFoundError:
            return False

    @commands.command(name="say")
    async def say(self, ctx, *, message: str):
        # Vérification des permissions
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Supprimer le message d'origine
        await ctx.message.delete()

        # Faire dire le bot
        await ctx.send(message)
        
async def setup(bot):
    await bot.add_cog(Say(bot))