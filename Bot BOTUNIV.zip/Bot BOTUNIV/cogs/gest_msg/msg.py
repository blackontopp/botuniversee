import discord
from discord.ext import commands
import json
import asyncio

class MessageManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def has_permission(self, ctx):
        """Vérifie si l'utilisateur est Buyer, Owner ou Mode"""
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            user_id = str(ctx.author.id)
            return any(user_id in users for role, users in roles_data.items() if role in ['buyer', 'owner', 'mode'])
        except FileNotFoundError:
            return False

    @commands.command(name="clear")
    async def clear_cmd(self, ctx, amount: int = 300):
        """Supprime un certain nombre de messages dans le salon"""
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        if amount <= 0:
            embed = discord.Embed(
                title="⚠️ Erreur",
                description="Le nombre de messages à supprimer doit être **supérieur à 0**.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        deleted = await ctx.channel.purge(limit=amount + 1)
        embed = discord.Embed(
            title="🧹 Salon nettoyé",
            description=f"**{len(deleted) - 1} messages** ont été supprimés avec succès.",
            color=0x9884fe
        )
        await ctx.send(embed=embed, delete_after=5)

    @commands.command(name="renew")
    async def renew_cmd(self, ctx):
        """Recrée le salon à l'identique et supprime l'ancien"""
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        old_channel = ctx.channel
        new_channel = await old_channel.clone(reason=f"Renouvellement par {ctx.author}")

        await new_channel.edit(position=old_channel.position)
        await old_channel.delete()

        embed = discord.Embed(
            title="🔄 Salon recréé",
            description=f"Le salon **{new_channel.mention}** a été recréé avec succès.",
            color=0x9884fe
        )
        await new_channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(MessageManagement(bot))