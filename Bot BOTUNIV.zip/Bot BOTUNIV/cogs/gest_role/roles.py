import discord
from discord.ext import commands
import json

class AllRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Vérifier si l'utilisateur a le rôle 'buyer' ou 'owner' en utilisant le fichier roles.json
    async def has_permission(self, ctx):
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifier si l'utilisateur est dans les rôles 'buyer' ou 'owner' en fonction du fichier
            user_id = str(ctx.author.id)

            for role, users in roles_data.items():
                if user_id in users:
                    if role in ['buyer', 'owner']:  # Vérification si l'utilisateur est buyer ou owner
                        return True
            return False
        except FileNotFoundError:
            return False

    @commands.command(name="addrole")
    async def addrole(self, ctx, member: discord.Member, role: discord.Role):
        # Vérification des permissions
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Ajouter le rôle au membre
        try:
            await member.add_roles(role)
            embed = discord.Embed(
                title="✅ Rôle ajouté",
                description=f"Le rôle **{role.name}** a été ajouté à **{member.name}**.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Erreur",
                description="Je n'ai pas les permissions nécessaires pour ajouter ce rôle.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)

    @commands.command(name="delrole")
    async def delrole(self, ctx, member: discord.Member, role: discord.Role):
        # Vérification des permissions
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Retirer le rôle du membre
        try:
            await member.remove_roles(role)
            embed = discord.Embed(
                title="✅ Rôle retiré",
                description=f"Le rôle **{role.name}** a été retiré de **{member.name}**.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Erreur",
                description="Je n'ai pas les permissions nécessaires pour retirer ce rôle.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AllRoles(bot))