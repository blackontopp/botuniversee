import discord
from discord.ext import commands
import json

class Massiverole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Vérifier si l'utilisateur a le rôle 'buyer' ou 'owner' en utilisant le fichier roles.json
    async def has_permission(self, ctx):
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifier si l'utilisateur est dans les rôles 'buyer' ou 'owner' en fonction du fichier
            user_id = str(ctx.author.id)

            for role, users in roles_data.items():
                if user_id in users:
                    if role in ['buyer', 'owner']:  # Vérification si l'utilisateur est buyer ou owner
                        return True
            return False
        except FileNotFoundError:
            return False

    @commands.command(name="massiverole")
    async def massiverole(self, ctx, action: str, role: discord.Role):
        # Vérification des permissions
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Vérifier si l'action est valide
        if action not in ['add', 'remove']:
            embed = discord.Embed(
                title="❌ Action invalide",
                description="L'action doit être `add` pour ajouter un rôle ou `remove` pour retirer un rôle.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Ajouter ou retirer le rôle à tous les membres
        members = ctx.guild.members
        failed_members = []

        for member in members:
            if action == 'add':
                try:
                    await member.add_roles(role)
                except discord.Forbidden:
                    failed_members.append(member)
            elif action == 'remove':
                try:
                    await member.remove_roles(role)
                except discord.Forbidden:
                    failed_members.append(member)

        # Préparer la réponse
        embed = discord.Embed(
            title="✅ Action réussie",
            description=f"Le rôle **{role.name}** a été **{action}** à tous les membres du serveur.",
            color=0x9884fe
        )

        if failed_members:
            failed_member_names = ", ".join([member.name for member in failed_members])
            embed.add_field(
                name="Membres échoués",
                value=f"Impossible d'ajouter/retirer le rôle à : {failed_member_names}.",
                inline=False
            )

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Massiverole(bot))