import discord
import json
from discord.ext import commands

class Hidder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_role(self, user_id, role):
        """Vérifie si l'utilisateur a un rôle spécifique en lisant `roles.json`."""
        try:
            with open("data/roles.json", "r") as f:
                roles_data = json.load(f)

            return str(user_id) in roles_data.get(role, {})

        except (FileNotFoundError, json.JSONDecodeError):
            return False

    @commands.command(name="hide")
    async def hide(self, ctx, channel: discord.TextChannel = None):
        """Cache un salon en empêchant @everyone de le voir."""
        user_id = str(ctx.author.id)

        # Vérification des permissions (Buyer, Owner et Mode uniquement)
        if not (self.has_role(user_id, "buyer") or self.has_role(user_id, "owner") or self.has_role(user_id, "mode")):
            embed = discord.Embed(
                title="⛔ Accès refusé",
                description="Vous n'avez pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        channel = channel or ctx.channel  # Si aucun salon n'est mentionné, utiliser celui où la commande est exécutée.

        # Modifier les permissions pour cacher le salon
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = False
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)

        embed = discord.Embed(
            title="🔒 Salon caché avec succès !",
            description=f"Le salon {channel.mention} a été **caché** pour @everyone.",
            color=0x9884fe
        )
        await ctx.send(embed=embed)

    @commands.command(name="unhide")
    async def unhide(self, ctx, channel: discord.TextChannel = None):
        """Affiche un salon en permettant à @everyone de le voir."""
        user_id = str(ctx.author.id)

        # Vérification des permissions (Buyer, Owner et Mode uniquement)
        if not (self.has_role(user_id, "buyer") or self.has_role(user_id, "owner") or self.has_role(user_id, "mode")):
            embed = discord.Embed(
                title="⛔ Accès refusé",
                description="Vous n'avez pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        channel = channel or ctx.channel  # Si aucun salon n'est mentionné, utiliser celui où la commande est exécutée.

        # Modifier les permissions pour afficher le salon
        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.view_channel = True
        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)

        embed = discord.Embed(
            title="🔓 Salon rendu visible !",
            description=f"Le salon {channel.mention} est **désormais visible** par @everyone.",
            color=0x9884fe
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Hidder(bot))