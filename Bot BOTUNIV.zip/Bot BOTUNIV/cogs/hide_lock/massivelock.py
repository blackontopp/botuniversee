import discord
import json
from discord.ext import commands

class MassiveLock(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_role(self, user_id, role):
        """Vérifie si l'utilisateur a un rôle spécifique en lisant `roles.json`."""
        try:
            with open("data/roles.json", "r") as f:
                roles_data = json.load(f)

            return str(user_id) in roles_data.get(role, {})

        except (FileNotFoundError, json.JSONDecodeError):
            return False

    @commands.command(name="massivelock")
    async def massivelock(self, ctx, action: str = None):
        """Verrouille ou déverrouille tous les salons du serveur."""
        user_id = str(ctx.author.id)

        # Vérification des permissions (seuls Buyer et Owner peuvent utiliser la commande)
        if not (self.has_role(user_id, "buyer") or self.has_role(user_id, "owner")):
            embed = discord.Embed(
                title="⛔ Accès refusé",
                description="Vous n'avez pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Vérification de l'argument (add/remove)
        if action not in ["add", "remove"]:
            embed = discord.Embed(
                title="❌ Mauvaise utilisation",
                description="Utilisation correcte : `+massivelock add` ou `+massivelock remove`",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        lock = action == "add"  # True si on veut verrouiller, False si on veut déverrouiller

        # Verrouillage/Déverrouillage de tous les salons
        for channel in ctx.guild.text_channels:
            overwrite = channel.overwrites_for(ctx.guild.default_role)
            overwrite.send_messages = not lock
            await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)

        status = "🔒 **verrouillés**" if lock else "🔓 **déverrouillés**"
        embed = discord.Embed(
            title=f"Tous les salons ont été {status} avec succès !",
            description=f"Action effectuée par {ctx.author.mention}.",
            color=0x9884fe
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(MassiveLock(bot))