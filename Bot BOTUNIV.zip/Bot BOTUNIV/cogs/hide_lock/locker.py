import discord
import json
from discord.ext import commands

class Locker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def has_role(self, user_id, role):
        """Vérifie si l'utilisateur a un rôle spécifique en lisant `roles.json`."""
        try:
            with open("data/roles.json", "r") as f:
                roles_data = json.load(f)

            return str(user_id) in roles_data.get(role, {})

        except (FileNotFoundError, json.JSONDecodeError):
            return False

    async def lock_unlock_channel(self, ctx, channel, lock: bool):
        """Gère le verrouillage/déverrouillage d'un salon."""
        user_id = str(ctx.author.id)

        # Vérifie si l'utilisateur a la permission d'utiliser la commande
        if not (self.has_role(user_id, "buyer") or self.has_role(user_id, "owner") or self.has_role(user_id, "mode")):
            embed = discord.Embed(
                title="⛔ Accès refusé",
                description="Vous n'avez pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        overwrite = channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = not lock

        await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)

        status = "🔒 **verrouillé**" if lock else "🔓 **déverrouillé**"
        embed = discord.Embed(
            title=f"Salon {status} avec succès !",
            description=f"{channel.mention} a été {status}.",
            color=0x9884fe
        )
        await ctx.send(embed=embed)

    @commands.command(name="lock")
    async def lock(self, ctx, channel: discord.TextChannel = None):
        """Verrouille un salon."""
        await self.lock_unlock_channel(ctx, channel or ctx.channel, lock=True)

    @commands.command(name="unlock")
    async def unlock(self, ctx, channel: discord.TextChannel = None):
        """Déverrouille un salon."""
        await self.lock_unlock_channel(ctx, channel or ctx.channel, lock=False)

async def setup(bot):
    await bot.add_cog(Locker(bot))