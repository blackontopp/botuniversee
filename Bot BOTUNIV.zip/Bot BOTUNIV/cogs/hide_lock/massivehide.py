import discord
from discord.ext import commands
import json

class MassiveHide(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Vérifier si l'utilisateur a le rôle 'buyer' ou 'owner' en utilisant le fichier roles.json
    async def has_permission(self, ctx):
        try:
            with open('data/roles.json', 'r') as f:
                roles_data = json.load(f)

            # Vérifier si l'utilisateur est dans les rôles 'buyer' ou 'owner' en fonction du fichier
            user_id = str(ctx.author.id)

            for role, users in roles_data.items():
                if user_id in users:
                    if role in ['buyer', 'owner']:  # Vérification si l'utilisateur est buyer ou owner
                        return True
            return False
        except FileNotFoundError:
            return False

    @commands.command(name="massivehide")
    async def massivehide(self, ctx, action: str = None):
        # Vérification des permissions
        if not await self.has_permission(ctx):
            embed = discord.Embed(
                title="🚫 Accès refusé",
                description="Tu n'as pas la permission d'utiliser cette commande.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Vérifier que l'action est correcte
        if action not in ["add", "remove"]:
            embed = discord.Embed(
                title="❌ Utilisation incorrecte",
                description="Utilisation : `+massivehide add` pour cacher tous les salons.\n"
                            "`+massivehide remove` pour les rendre visibles.",
                color=0x9884fe
            )
            return await ctx.send(embed=embed)

        # Si l'action est "add", on cache tous les salons
        if action == "add":
            for channel in ctx.guild.text_channels:
                try:
                    # Cache le salon en empêchant sa lecture par tous les utilisateurs
                    await channel.set_permissions(ctx.guild.default_role, read_messages=False)
                except discord.Forbidden:
                    pass

            embed = discord.Embed(
                title="✅ Tous les salons sont maintenant invisibles",
                description="Tous les salons textuels ont été rendus invisibles pour les membres.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)

        # Si l'action est "remove", on rend les salons visibles à nouveau
        elif action == "remove":
            for channel in ctx.guild.text_channels:
                try:
                    # Rend le salon visible pour tous les utilisateurs
                    await channel.set_permissions(ctx.guild.default_role, read_messages=True)
                except discord.Forbidden:
                    pass

            embed = discord.Embed(
                title="✅ Tous les salons sont maintenant visibles",
                description="Tous les salons textuels ont été rendus visibles.",
                color=0x9884fe
            )
            await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(MassiveHide(bot))